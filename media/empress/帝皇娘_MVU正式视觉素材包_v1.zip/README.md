# 帝皇娘正式视觉素材包 v1

目标仓库目录：`media/empress/`

硬规则：
- 唯一主立绘：EMP-BASE-01.webp
- 锁屏圆章：EMP-LOCK-01.webp
- 箴言侧影：EMP-QUOTE-01.webp
- 复活区：EMP-REVIVE-01.webp（只裁半身，不使用复杂手势）
- 法典/死亡签氛围：EMP-CODEX-01.webp
- ALT 文件仅备用，不得擅自替换主立绘
- 禁止搜索/生成新的帝皇娘人物图混入 MVU
